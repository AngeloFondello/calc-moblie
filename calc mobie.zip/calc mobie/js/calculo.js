
/*Crio  uma varialvel para cada botão*/
var soma=document.getElementById("soma");

var menos=document.getElementById("subtrai");

var divisao=document.getElementById("divide");

var vezes=document.getElementById("multiplica");

var igual=document.getElementById("resulta");

var c=document.getElementById("c");

var um=document.getElementById("um");

var dois=document.getElementById("dois");

var tres=document.getElementById("tres");

var quatro=document.getElementById("quatro");

var cinco=document.getElementById("cinco");

var seis=document.getElementById("seis");

var sete=document.getElementById("sete");

var oito=document.getElementById("oito");

var nove=document.getElementById("nove");

var zero=document.getElementById("zero");

//variavei para dizer como os calculos vão funcionar
vl1=0;
vl2=0;
operacao=0;


//digo qe cada operação vai ser igual a um numero
//assim fica masi facil de criar as funções
soma.addEventListener("click",function(){	

		vl1 = tela.value;	
		tela.value = null;
		operacao=1;
})
subtrai.addEventListener("click",function(){	

		vl1 = tela.value;	
		tela.value = null;
		operacao=2;		
})
divide.addEventListener("click",function(){	

		vl1 = tela.value;		
		tela.value = null;
		operacao=3;	
})
multiplica.addEventListener("click",function(){	

		vl1 = tela.value;
		tela.value = null;	
		operacao=4;
})
resulta.addEventListener("click",function(){


	vl2= tela.value;
	if (operacao==1) {
		op=parseFloat(vl1)+parseFloat(vl2);
		tela.value=op;
	}
	else if (operacao==2) {
		op=parseFloat(vl1)-parseFloat(vl2);	
		tela.value=op;
	}	
	else if (operacao==3) {
		op=parseFloat(vl1)/parseFloat(vl2);	
		tela.value=op;
	}
	else if (operacao==4) {
		op=parseFloat(vl1)*parseFloat(vl2);	
		tela.value=op;
	}
	
})

c.addEventListener("click",function(){
	tela.value=null;
	vl1=0;
	vl2=0;
})


/*Aqui é onde eu digo que o evento do click em um botã 
vai fazer com que apareça na tela seu respectivo numero*/
	um.addEventListener("click",function(){
		tela.value+="1";
	})
	dois.addEventListener("click",function(){
		tela.value+="2";
	})
	tres.addEventListener("click",function(){
		tela.value+="3";
	})
	quatro.addEventListener("click",function(){
		tela.value+="4";
	})
	cinco.addEventListener("click",function(){
		tela.value+="5";
	})
	seis.addEventListener("click",function(){
		tela.value+="6";
	})
	sete.addEventListener("click",function(){
		tela.value+="7";
	})
	oito.addEventListener("click",function(){
		tela.value+="8";
		
	})
	nove.addEventListener("click",function(){
		tela.value+="9";
	})
	zero.addEventListener("click",function(){
		tela.value+="0";
	})

